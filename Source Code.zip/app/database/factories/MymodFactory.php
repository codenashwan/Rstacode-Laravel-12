<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\mymod;
use Faker\Generator as Faker;

$factory->define(mymod::class, function (Faker $faker) {
    return [
        //
    ];
});
