@extends('layout.layout')


@section('content')
<span class="text-white ml-5 border border-white p-1 radius-10">WELCOME TO SHOP.COM</span>
<div class="row justify-content-center m-3">

    <div class="card p-3 m-2 radius-10 border-0" style="width: 18rem;">
        <img src="assets/img/login.svg" class="w-50 m-auto" alt="...">
        <div class="card-body text-center">
          <h5 class="card-title text-danger">Login / Register</h5>
          <a href="/login" class="btn bg-gradient-danger border-0 text-white w-100">Add Product</a>
        </div>
      </div>

      <div class="card p-3 m-2 radius-10 border-0" style="width: 18rem;">
        <img src="assets/img/home.svg" class="w-50 m-auto" alt="...">
        <div class="card-body text-center">
          <h5 class="card-title text-success">Products</h5>
          <h5 class="text-danger">{{ session("file_order") }}</h5>
          <h5 class="text-success">{{ session("success_order") }}</h5>
          <a href="/shopping" class="btn bg-gradient-success border-0 text-white w-100">View Shopping</a>
        </div>
      </div>

      <div class="card p-3 m-2 radius-10 border-0" style="width: 18rem;">
        <img src="assets/img/shopper.svg" class="w-50 m-auto" alt="...">
        <div class="card-body text-center">
          <h5 class="card-title text-primary">Shoppers</h5>
          <a href="/shopper" class="btn bg-gradient-primary border-0 text-white w-100">View Shoppers</a>
        </div>
      </div>

      <div class="card p-3 m-2 radius-10 border-0" style="width: 18rem;">
        <img src="assets/img/contact.svg" class="w-50 m-auto" alt="...">
        <div class="card-body text-center">
          <h5 class="card-title text-primary">Contact</h5>
        <h5 class="text-success">{{ session("success") }}</h5>
          <a href="/contact" class="btn btn-primary border-0 text-white w-100">Contact Us</a>
        </div>
      </div>

</div>
@endsection
