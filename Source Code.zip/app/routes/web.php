<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome' );
});

Route::get('/login', function () {
    return view('login' , ["username" => "nashwan" , "password" => "1234"]);
});
Route::get('/contact', function () {
    return view('contact');
});

Route::post('/contact' , 'ShopController@saveContact');
Route::get('/shopping', 'ShopController@index');
Route::get('/shopper', 'ShopController@viewShpper');
Route::get('/shopper/{id}', 'ShopController@show');
Route::get('/shopper/{id}/{postid}', 'ShopController@getDetails');
Route::get('/update', 'ShopController@update');
Route::get('/cookie', 'ShopController@Guest');
Route::get('/delete/{id}', 'ShopController@delete')->middleware('auth');
Route::post('order' , 'ShopController@order');
Route::get('/cart', 'ShopController@cart');

Auth::routes(
[
    'register' => false
]

);


Route::get('/home', 'HomeController@index')->name('home');

Route::get('/getid', 'ShopController@get_user_id');
