<?php $__env->startSection('content'); ?>

    <div class="row m-3 justify-content-center">
        <?php $__currentLoopData = $shoppers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card m-2 p-2" style="width: 18rem;">
            <img src="https://image.flaticon.com/icons/svg/679/679946.svg" class="card-img-top w-50 m-auto" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($shopper->name); ?></h5>
              <h5 class="card-title"><?php echo e($shopper->email); ?></h5>
              <a href="/shopper/<?php echo e($shopper->id); ?>" class="btn btn-primary">See Profile</a>
            </div>
          </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/shopper/shopper.blade.php ENDPATH**/ ?>