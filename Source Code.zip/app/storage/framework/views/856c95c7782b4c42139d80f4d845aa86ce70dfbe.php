<?php $__env->startSection('content'); ?>

this is login <a href="/">home</a>

<?php echo e($username); ?>

<?php echo e($password); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/login.blade.php ENDPATH**/ ?>