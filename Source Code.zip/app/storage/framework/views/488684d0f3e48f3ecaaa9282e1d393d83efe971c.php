This is Shoper Id : <?php echo e($id); ?> and This is Department Id <?php echo e($departId); ?> and This is Classid <?php echo e($ClassId); ?>

<?php /**PATH C:\xampp\htdocs\app\resources\views/shopper.blade.php ENDPATH**/ ?>