<?php $__env->startSection('content'); ?>
    <div class="row m-3 justify-content-center">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-3 m-2" style="width: 18rem;">
            <img src="upload/<?php echo e($product->image); ?>" class="card-img-top w-50 m-auto" alt="">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($product['title']); ?></h5>
                <p class="card-text"><?php echo e($product['price']); ?></p>
                <a href="shopper/<?php echo e($product->userid); ?>/<?php echo e($product->id); ?>" class="btn btn-info">View More</a>
                <?php if($product->userid == $userid): ?>
                <a href="delete/<?php echo e($product->id); ?>" class="text-danger">Delete</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/shopping.blade.php ENDPATH**/ ?>