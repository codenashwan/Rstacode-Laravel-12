

<?php $__env->startSection('content'); ?>

<div class="jumbotron jumbotron-fluid bg-white p-3 radius-10">
    <div class="container text-center">
        <img src="/upload/<?php echo e($product->image); ?>" class="card-img-top w-25 m-auto radius-10 shadow">
        <h5 class="mt-5">Product Code : <?php echo e($product->id); ?></h5>
        <h5>Product Price : <?php echo e($product->price); ?></h5>
        <p class="p-3 radius-10 bg-gradient-lighter">
            <b>Product Details :</b>
            <br>
            <?php echo e($product->details); ?>

            <form action="/order" method="post">
                <?php echo csrf_field(); ?>
            <div class="d-flex justify-content-center">
                <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-checkbox m-3">
                    <input class="custom-control-input" id="<?php echo e($size); ?>" type="checkbox" name="sizes[]" value="<?php echo e($size); ?>">
                    <label class="custom-control-label" for="<?php echo e($size); ?>"><?php echo e($size); ?></label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" value="<?php echo e($product->id); ?>" name="post_id">

            </div>
        </p>
        <button class="btn btn-success">Add To Cart</button>
    </div>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/shopper/details.blade.php ENDPATH**/ ?>