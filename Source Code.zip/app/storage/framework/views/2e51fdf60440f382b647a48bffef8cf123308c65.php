<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shop</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Baloo+Paaji+2&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://demos.creative-tim.com/argon-design-system/assets/css/argon-design-system.min.css?v=1.2.0">
</head>
<body class="bg-gradient-blue container">
    <nav class="navbar navbar-expand-lg p-1 m-3 navbar-light bg-white radius-10">
        <a class="navbar-brand" href="/"><img src="assets/img/logo.svg" width="50" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="/">Home</a>
            </li>
          </ul>

        </div>
      </nav>



<?php echo $__env->yieldContent('content'); ?>
<footer class="p-2 bg-white text-center container mt-4 radius-10">All Right Reserved 2020 Rstacode</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\app\resources\views////layout/layout.blade.php ENDPATH**/ ?>